function R = resfunc(w, x, y)
    R = objfunc(w, x) - y;
end