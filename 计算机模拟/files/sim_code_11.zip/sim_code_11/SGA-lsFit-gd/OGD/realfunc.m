function y = realfunc(x)
    y = x .* x; 
end