function f = sigmoid(x)
f = 1.0./(1.0+exp(-x));
